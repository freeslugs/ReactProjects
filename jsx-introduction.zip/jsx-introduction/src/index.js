import React from 'react';
import ReactDOM from 'react-dom';
import App from './App';
import registerServiceWorker from './registerServiceWorker';
import './index.css';

class NameForm extends React.Component{
	constructor(props){
		super(props);
		this.state = {
			user: {
				firstName: null,
				lastName: null
			}
		};

		this.handleFirstNameChange = this.handleFirstNameChange.bind(this);
		this.handleLastNameChange = this.handleLastNameChange.bind(this);
		this.handleSubmit = this.handleSubmit.bind(this);
	}

	handleFirstNameChange(event){
		this.setState({user:{ 
			firstName: event.target.value,
			lastName: this.state.user.lastName
		}});
	}

	handleLastNameChange(event){
		this.setState({user:{ 
			lastName: event.target.value,
			firstName: this.state.user.firstName
		}});
	}

	handleSubmit(event){
		//***This part Works and can be used as a test: ***
		//alert("Your input: " + this.state.user.firstName + " " + this.state.user.lastName);

		//**** This part is not working unfortunately: ***
		<getGreeting user={this.state.user} />;
		

		event.preventDefault();
	}

	render(){
		return(
			<div>
				<form onSubmit= {this.handleSubmit}>
					First Name:
					<input type = "text" value = {this.state.user.firstName} onChange={this.handleFirstNameChange} />
					<br />
					Last Name:
					<input type = "text" value = {this.state.user.lastName} onChange={this.handleLastNameChange} />
					<br />
					<input type="submit" value="Submit" />
				</form>
			</div>
			);
	}
}

class Greeting extends React.Component{
	constructor(){
		super();
		this.state={
			user: {
				firstName: null,
				lastName: null
			}
		};
	};

	render(){
		return(
			getGreeting(this.state.user)
			);
	}
}


function formatName(user){
	return user.firstName + ' ' + user.lastName;
}

function getGreeting(user){
	if(user.firstName != null && user.lastName != null){
		return <h1> Hello, {formatName(user)}! </h1>;
	}
	else{
		return <h1> Hello, Stranger. </h1>;
	}
}

ReactDOM.render(
	<div>
		<Greeting />
		<NameForm />
	</div>,
	document.getElementById('root'));
